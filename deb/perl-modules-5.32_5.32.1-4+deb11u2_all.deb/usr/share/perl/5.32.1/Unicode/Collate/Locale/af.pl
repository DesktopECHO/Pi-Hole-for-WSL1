+{
   locale_version => 1.27,
   entry => <<'ENTRY', # for DUCET v10.0.0
0149      ; [.1E1F.0020.0009] # LATIN SMALL LETTER N PRECEDED BY APOSTROPHE
ENTRY
};
